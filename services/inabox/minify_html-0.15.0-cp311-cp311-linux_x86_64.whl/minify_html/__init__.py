from .minify_html import *

__doc__ = minify_html.__doc__
if hasattr(minify_html, "__all__"):
    __all__ = minify_html.__all__